import maya.cmds as mc

mc.evalDeferred("import aniseed;aniseed.environment.initialize()")
